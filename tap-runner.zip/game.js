const c = document.getElementById('canvas');
const ctx = c.getContext('2d', { alpha:false });
const ui = document.getElementById('ui');

let W=0,H=0, DPR = Math.min(2, window.devicePixelRatio||1);
function resize(){
  W = Math.floor(innerWidth * DPR);
  H = Math.floor(innerHeight * DPR);
  c.width = W; c.height = H;
}
addEventListener('resize', resize); resize();

function msg(html){
  ui.innerHTML = `<div class="msg">${html}</div>`;
}
function clearMsg(){ ui.innerHTML = ''; }

let running=false, score=0, best=0;
let player = { x:0, y:0, vy:0, r:18*DPR, onGround:false };
let gravity = 0.7*DPR, jumpV = -11*DPR;
let pipes = [];
let speed = 4*DPR;

function reset(){
  score=0; speed=4*DPR;
  player.x = Math.floor(W*0.25);
  player.y = Math.floor(H*0.7);
  player.vy = 0; player.onGround = true;
  pipes = [];
  for(let i=1;i<=4;i++) addPipe(W + i* (W/3));
}

function addPipe(x){
  const gap = Math.max(110*DPR, 180*DPR - score*2);
  const topH = 60*DPR + Math.random() * (H - gap - 160*DPR);
  pipes.push({ x, w:50*DPR, top: topH, gap });
}

function start(){
  clearMsg();
  reset();
  running = true;
  requestAnimationFrame(loop);
}

function gameOver(){
  running=false;
  best = Math.max(best, score);
  msg(`💥 הפסדת<br>ניקוד: ${score} | שיא: ${best}<br><a class="btn" href="#" id="again">שחק שוב</a>`);
  document.getElementById('again').onclick = (e)=>{ e.preventDefault(); start(); };
}

function tap(ev){
  ev && ev.preventDefault();
  if(!running){ start(); return; }
  player.vy = jumpV;
  player.onGround=false;
}
addEventListener('pointerdown', tap, {passive:false});
addEventListener('keydown', e=>{ if(e.code==='Space') tap(e); });

function loop(){
  if(!running) return;
  update();
  draw();
  requestAnimationFrame(loop);
}

function update(){
  // physics
  player.vy += gravity;
  player.y += player.vy;
  const groundY = Math.floor(H*0.8);
  if(player.y > groundY){ player.y = groundY; player.vy=0; player.onGround=true; }

  // pipes
  for(const p of pipes){ p.x -= speed; }
  if(pipes.length && pipes[0].x + pipes[0].w < 0){
    pipes.shift();
    addPipe(pipes[pipes.length-1].x + (W/3));
    score++;
    if(score % 5 === 0) speed += 0.6*DPR;
  }

  // collision
  for(const p of pipes){
    const collideX = player.x + player.r > p.x && player.x - player.r < p.x + p.w;
    if(collideX){
      const gapTop = p.top;
      const gapBottom = p.top + p.gap;
      if(player.y - player.r < gapTop || player.y + player.r > gapBottom){
        gameOver(); return;
      }
    }
  }
}

function draw(){
  // bg
  ctx.fillStyle = '#111'; ctx.fillRect(0,0,W,H);

  // ground
  const groundY = Math.floor(H*0.8);
  ctx.fillStyle = '#0a0a0a';
  ctx.fillRect(0, groundY, W, H-groundY);

  // pipes
  ctx.fillStyle = '#2ecc71';
  for(const p of pipes){
    ctx.fillRect(p.x, 0, p.w, p.top);
    ctx.fillRect(p.x, p.top + p.gap, p.w, H - (p.top + p.gap));
  }

  // player
  ctx.fillStyle = '#09f';
  ctx.beginPath();
  ctx.arc(player.x, player.y, player.r, 0, Math.PI*2);
  ctx.fill();

  // score
  ctx.fillStyle = '#fff';
  ctx.font = `${24*DPR}px system-ui, Arial`;
  ctx.textAlign = 'left';
  ctx.fillText(`ניקוד: ${score}`, 16*DPR, 32*DPR);
  ctx.textAlign = 'right';
  ctx.fillText(`שיא: ${best}`, W - 16*DPR, 32*DPR);
}

// start screen
msg(`🚀 Tap Runner<br>נגיעה במסך = קפיצה<br><a class="btn" href="#" id="start">יאללה, התחל</a>`);
document.getElementById('start').onclick = (e)=>{ e.preventDefault(); start(); };
